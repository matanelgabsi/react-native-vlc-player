//
// Created by yyl on 2018/5/24.
//
#include "../log.h"
// /libvlc/jni/vout.c
// void jni_UnlockAndroidSurface() {
//    pthread_mutex_unlock(&vout_android_lock);
//}
//
//bool jni_LockAndGetIsSurfaceAttached() {
//        pthread_mutex_unlock(&vout_android_lock);
//        return vout_android_java_surf != NULL;
//    }
//

void fixSurfaceThread(){


}